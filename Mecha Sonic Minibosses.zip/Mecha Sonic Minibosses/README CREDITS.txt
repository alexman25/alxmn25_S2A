 Sonic & Knuckles - Mini Boss (Sonic 2 Remix) by TheLegendofRenegade
 https://youtu.be/37VLNMiuucA?si=O2um8b13pQRzMl7h